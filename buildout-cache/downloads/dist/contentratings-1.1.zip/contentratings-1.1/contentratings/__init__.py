# Initialize the Zope 2 permissions stuff as needed
import permissions
permissions  # pyflakes
