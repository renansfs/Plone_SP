# -*- coding:utf-8 -*-
from collective.nitf.config import PROJECTNAME

import logging


logger = logging.getLogger(PROJECTNAME)
