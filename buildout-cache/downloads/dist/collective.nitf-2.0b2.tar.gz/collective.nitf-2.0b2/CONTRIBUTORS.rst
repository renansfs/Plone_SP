Share and Enjoy
---------------

``collective.nitf`` would not have been possible without the contribution of
the following people:

- Cleber J. Santos
- Franco Pellegrini
- Gonzalo Almeida
- Héctor Velarde
- Joaquín Rosales
- Juan A. Díaz
- Juan Pablo Giménez
- Marcos F. Romero
- Silvestre Huens
- Érico Andrei
- Rodrigo Ferreira de Souza
- Wolfgang Beyer (`Mandelbrot image set <https://commons.wikimedia.org/wiki/File:Mandel_zoom_00_mandelbrot_set.jpg>`_ used in tests)

You can find an updated list of package contributors on `GitHub`_.

Development sponsored by Open Multimedia.

.. _`GitHub`: https://github.com/collective/collective.nitf/contributors
