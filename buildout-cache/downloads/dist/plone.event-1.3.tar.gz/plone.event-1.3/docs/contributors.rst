Contributions by
----------------
Contributors, please add you name here! By doing this, you also state, that you
have signed the Plone Contributors Agreement [1][2]. Thanks!

- Johannes Raggam, thet

To be confirmed:
- Kai Lautaportti <kai.lautaportti@hexagonit.fi>
- Philip Bauer <bauer@starzel.de>
- Robert Niederreiter <office@squarewave.at>
- Simone Orsi <simahawk@simahost.domsense.com>
- Taito Horiuchi <taito.horiuchi@hexagonit.fi>
- Tom Gross <tom@toms-projekte.de>
- Vincent Fretin <vincent.fretin@gmail.com>
- Vitaliy Podoba <vitaliypodoba@gmail.com>


[1] http://plone.org/foundation/contributors-agreement/contributors-agreement-explained
[2] http://plone.org/foundation/contributors-agreement/agreement.pdf/view
