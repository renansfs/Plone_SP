from zope.i18nmessageid import MessageFactory

messageFactory = MessageFactory('plone.contentratings')

def initialize(context):
    """Initializer called when used as a Zope 2 product."""
