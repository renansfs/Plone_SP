Overview
********

`plone.contentratings` is an add-on package for the Plone content
management system.  It extends the Zope3 package `contentratings` to
provide through the web configurable rating categories for all CMF
content.  It AJAX-ifies the rating UI using KSS actions.
