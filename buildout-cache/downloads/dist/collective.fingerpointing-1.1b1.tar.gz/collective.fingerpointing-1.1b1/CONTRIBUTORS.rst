Share and Enjoy
===============

This package would not have been possible without the contribution of the following people:

- Héctor Velarde
- René Jochum <rene@webmeisterei.com>
- Harald Friessnegger (Webmeisterei GmbH)
- Font Awesome (`icon`_)

You can find an updated list of package contributors on `GitHub`_.

.. _`GitHub`: https://github.com/collective/collective.fingerpointing/contributors
.. _`icon`: http://fontawesome.io/icon/hand-o-right/
