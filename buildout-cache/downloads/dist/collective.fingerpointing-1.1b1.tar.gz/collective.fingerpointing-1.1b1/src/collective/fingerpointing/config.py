# -*- coding: utf-8 -*-
PROJECTNAME = 'collective.fingerpointing'

AUDITLOG = 'audit.log'
AUDIT_MESSAGE = u'user={0} ip={1} action={2} {3}'
