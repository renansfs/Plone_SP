from zope.interface import Interface


class IElephantVocabulary(Interface):
    """marker interface for vocabs we wrap
    """
