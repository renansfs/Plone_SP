Credits
=======

Generously sponsored by `4teamwork`_.

 * `Rok Garbas`_, author


Todo
====

 * provide test / documentation for custom wrapper class
 * coverage should show 100%, but its failing on method and import lines, weird.

.. _`Rok Garbas`: http://www.garbas.si
.. _`4teamwork`: http://4teamwork.ch
