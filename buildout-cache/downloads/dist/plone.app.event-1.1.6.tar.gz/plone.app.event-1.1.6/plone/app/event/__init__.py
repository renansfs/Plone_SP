from zope.i18nmessageid import MessageFactory

packageName = __name__
messageFactory = MessageFactory(packageName)
PloneMessageFactory = MessageFactory('plone')
