plone.app.event.portlets.portlet_calendar
=========================================

.. automodule:: plone.app.event.portlets.portlet_calendar
    :members:
