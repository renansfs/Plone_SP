plone.app.event.browser.controlpanel
====================================

.. automodule:: plone.app.event.browser.controlpanel
    :members:
