plone.app.event.vocabularies
============================

.. automodule:: plone.app.event.vocabularies
    :members:
