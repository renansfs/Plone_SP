plone.app.event.setuphandlers
=============================

.. automodule:: plone.app.event.setuphandlers
    :members:
