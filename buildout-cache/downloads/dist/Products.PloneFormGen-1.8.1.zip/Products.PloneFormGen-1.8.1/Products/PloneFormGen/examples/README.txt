The PFGDataGrid field add-on example is now an independent product.

See http://plone.org/products/pfgdatagrid
