API Reference
-------------

icalendar.cal
+++++++++++++

.. automodule:: icalendar.cal
   :members:

icalendar.prop
++++++++++++++

.. automodule:: icalendar.prop
   :members:
