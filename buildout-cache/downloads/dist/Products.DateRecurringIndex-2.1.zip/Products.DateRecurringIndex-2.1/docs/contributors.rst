Contributions by
----------------
Contributors, please add you name here! By doing this, you also state, that you
have signed the Plone Contributors Agreement [1][2]. Thanks!

- Jens Klein, yenzenz (Original implementation)
- Johannes Raggam, thet
- Róman Joost, romanofski
- Dorneles Tremea, Dorneles
- Sean Upton, supton


[1] http://plone.org/foundation/contributors-agreement/contributors-agreement-explained
[2] http://plone.org/foundation/contributors-agreement/agreement.pdf/view
