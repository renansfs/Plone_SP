from zope.i18nmessageid import MessageFactory
_ = MessageFactory('plone')

from plone.formwidget.autocomplete.widget import AutocompleteFieldWidget
from plone.formwidget.autocomplete.widget import AutocompleteMultiFieldWidget
