from zope.interface import Interface


class IAutocompleteWidget(Interface):
    """Marker interface for the autocomplete widget
    """
