"""Common configuration constants
"""

PROJECTNAME = 'auslfe.formonline.content'

ADD_PERMISSIONS = {
    # -*- extra stuff goes here -*-
    'FormOnline': 'auslfe.formonline.content: Add FormOnline',
}
