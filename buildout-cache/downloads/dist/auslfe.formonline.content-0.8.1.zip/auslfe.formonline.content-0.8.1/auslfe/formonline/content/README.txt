Please, see doctest in `auslfe.formonline.pfgadapter`__

__ http://plone.org/products/auslfe.formonline.pfgadapter
