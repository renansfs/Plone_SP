from zope.interface import Interface

class IFormOnline(Interface):
    """Marker interface for a FormOnline content"""
    
