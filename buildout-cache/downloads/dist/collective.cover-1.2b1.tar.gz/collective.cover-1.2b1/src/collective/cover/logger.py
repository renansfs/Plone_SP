# -*- coding: utf-8 -*-
from collective.cover.config import PROJECTNAME
import logging

logger = logging.getLogger(PROJECTNAME)
