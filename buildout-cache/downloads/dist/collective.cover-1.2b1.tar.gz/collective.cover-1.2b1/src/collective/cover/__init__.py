# -*- coding: utf-8 -*-
from zope.i18nmessageid import MessageFactory

_ = MessageFactory('collective.cover')
