# -*- coding: utf-8 -*-
from pkg_resources import resource_filename

PATH_TO_TEST_FILES = resource_filename("plone.app.contenttypes.tests", "")
