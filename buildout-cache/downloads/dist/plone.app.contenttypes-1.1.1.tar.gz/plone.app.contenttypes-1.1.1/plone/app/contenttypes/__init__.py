# -*- coding: utf-8 -*-
from zope.i18nmessageid import MessageFactory
import permissions  # noqa
permissions  # pyflakes

_ = MessageFactory('plone')
