from zope.i18nmessageid import MessageFactory


_ = MessageFactory('plone')
