Contributions by
----------------
Contributors, please add you name here! By doing this, you also state, that you
have signed the Plone Contributors Agreement [1][2]. Thanks!

- Vincent Fretin - vincentfretin
- Rok Garbas - garbas
- David Glick - davisagli
- Simone Orsi
- Johannes Raggam - thet
- Carsten Senger - csenger
- Taito Horiuchi - Taito
- Lennart Regebro - regebro
- Mathieu Le Marec - Pasquet - kiorky
- Kai Lautaportti - dokai
- Denis Krienbühl - href

To be confirmed:
- Sean Upton <sdupton@gmail.com>


[1] http://plone.org/foundation/contributors-agreement/contributors-agreement-explained
[2] http://plone.org/foundation/contributors-agreement/agreement.pdf/view
