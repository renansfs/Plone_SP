# Convenience import

from widget import WysiwygFieldWidget

