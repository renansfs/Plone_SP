from zope.interface import Interface
from zope.schema.interfaces import IList


class IQueryStringWidget(Interface):
    """Marker interface for the querystring widget"""
