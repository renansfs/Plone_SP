# -*- coding: utf-8 -*-
from zope.interface import Interface


class IAddOnInstalled(Interface):

    """A layer specific for this add-on product."""
