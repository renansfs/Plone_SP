Share and Enjoy
===============

``collective.js.cycle2`` would not have been possible without the contribution of the following people:

- Héctor Velarde
- Rodrigo Ferreira de Souza
- Mike Alsup (`Cycle2`_)

You can find an updated list of package contributors on `GitHub`_.

Development sponsored by `Simples Consultoria`_.

.. _`Cycle2`: http://jquery.malsup.com/cycle2/
.. _`GitHub`: https://github.com/collective/collective.js.cycle2/contributors
.. _`Simples Consultoria`: http://www.simplesconsultoria.com.br/
