Changelog
=========

There's a frood who really knows where his towel is.

1.0b2 (2016-07-20)
------------------

- Fade in slideshows to avoid showing them before Cycle2 is loaded.
  [rodfersou]

- Add `utils.js` script;
  this script can be used by third party add-ons to easily create responsive slideshows.
  [rodfersou]


1.0b1 (2015-05-27)
------------------

- Remove browser layer and JS resource registry registrations.
  Include all Cycle2 and plugins code as browser resources (closes `#1`_).
  [rodfersou]


1.0a1 (2014-10-20)
------------------

- Initial release.

.. _`#1`: https://github.com/collective/collective.js.cycle2/issues/1
