/* The following line defines global variables defined elsewhere. */
/*globals $, jQuery*/

jQuery(function ($) {
    $('#portal-globalnav .noClick').click(function (e) {
        e.preventDefault();
    });
});