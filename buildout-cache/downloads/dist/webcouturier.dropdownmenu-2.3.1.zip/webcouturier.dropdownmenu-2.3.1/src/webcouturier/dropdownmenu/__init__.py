from AccessControl import allow_module

allow_module('webcouturier.dropdownmenu.utils')


def initialize(context):
    """Initializer called when used as a Zope 2 product."""
