Introduction
============

This product is an integration of JQuery Colorpicker plugin for Plone.

Installation
============

This isn't a standalone product. If you need colorpicker jquery plugin for your
needs in a plone package, just add collective.js.jquery in the install_requires
of your product.

And add your own javascript code setting colorpicker on your input.

Read the plugin documentation here: http://www.eyecon.ro/colorpicker/

Example of products using this package:

   - Solgema.fullcalendar

Credits
=======

Jquery Plugin
-------------

http://www.eyecon.ro/colorpicker/

Dual licensed under the MIT and GPL licenses.

Integration
-----------

Plone integration By Thomas Desvenain