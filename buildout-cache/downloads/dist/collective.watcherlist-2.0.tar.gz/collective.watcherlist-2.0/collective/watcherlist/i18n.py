from zope import i18nmessageid

_ = i18nmessageid.MessageFactory("collective.watcherlist")
