from zope.interface import Interface, Attribute
from plone.theme.interfaces import IDefaultPloneLayer

class ISolgemaContextualContentMenuLayer(IDefaultPloneLayer):
    """Solgema ContextualContentMenu layer""" 
