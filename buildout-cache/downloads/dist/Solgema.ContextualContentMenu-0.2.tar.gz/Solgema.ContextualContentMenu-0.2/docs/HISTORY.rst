Changelog
=========

0.2
---

- Define ``jq`` variable in JS for plone sites where ``jquery-integration.js``
  is not delivered.
  [rnix]


0.1
---

- Initial release.
  [Martronic]

