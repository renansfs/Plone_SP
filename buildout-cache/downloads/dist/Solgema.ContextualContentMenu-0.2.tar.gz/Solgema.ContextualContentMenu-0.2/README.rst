Solgema.ContextualContentMenu
=============================

Adds a right click menu that shows Plone's content and action menu.
(used in Solgema.fullcalendar and Solgema.NavigationPortlet)
