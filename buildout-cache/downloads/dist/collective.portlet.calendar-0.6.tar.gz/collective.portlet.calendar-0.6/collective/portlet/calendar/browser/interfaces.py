from zope.interface import Interface

class ICalendarExLayer(Interface):
    """ Marker interface that defines a Zope 3 browser layer
    """