# -*- coding: utf-8 -*-
from sc.social.like.config import PROJECTNAME

import logging

logger = logging.getLogger(PROJECTNAME)
