import logging
from zope.i18nmessageid import MessageFactory

log = logging.getLogger('Solgema.fullcalendar')
msg_fact = MessageFactory('Solgema.fullcalendar')
