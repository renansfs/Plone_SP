from z3c.form.browser.interfaces import IHTMLTextInputWidget
from z3c.form.interfaces import ITextWidget

class IHTMLDictTextInputWidget(IHTMLTextInputWidget):
    """"""

class IColorDictTextWidget(ITextWidget):
    """ColorDict widget."""
