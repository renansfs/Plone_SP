from Products.CMFCore.permissions import AddPortalContent

ADD_CONTENT_PERMISSION = AddPortalContent
PROJECTNAME = "ArchAddOn"
SKINS_DIR = 'skins'

GLOBALS = globals()
INSTALL_SAMPLE_TYPES = False
