"""
    Module initialization code
    
    Used by auslfe.formonline.pfgadapter/__init__.py

"""

import formOnlineAdapter
formOnlineAdapter