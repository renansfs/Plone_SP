Introduction
============

This package include javascripts and css resources from `arshaw fullcalendar <http://arshaw.com/fullcalendar/>`_.

It does not provide any view or template. Is meant to be used as dependecy for building your own calendar views.

Tested with Plone 3.3.5/4.0.

Now using fullcalendar v1.6
