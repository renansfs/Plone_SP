from zope.interface import Interface

class IStorageStrategyChanging(Interface):
    """event"""

