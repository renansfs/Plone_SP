from zope.interface import Interface


class ILoveThumbsDontYou(Interface):
    """ Marker to show the thumbs up and thumbs down viewlet
    """
