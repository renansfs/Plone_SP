# this file is here to make Install.py importable.
# we need to make it non-zero size to make winzip cooperate
