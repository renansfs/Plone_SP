jQuery(function($) {
    // No overlays for IE6
    if (!jQuery.browser.msie ||
        parseInt(jQuery.browser.version, 10) >= 7) {

        // Set up overlays
        $('#poi-login-form').prepOverlay({
            subtype: 'ajax',
            filter: '#content>*',
            formselector: '#content-core > form',
            noform: 'reload',
            closeselector: '[name=form.buttons.cancel]',
        });
    }
});
