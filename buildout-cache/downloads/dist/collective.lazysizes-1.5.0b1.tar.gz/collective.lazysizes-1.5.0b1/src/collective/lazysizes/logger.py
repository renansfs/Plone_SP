# -*- coding: utf-8 -*-
from collective.lazysizes.config import PROJECTNAME

import logging


logger = logging.getLogger(PROJECTNAME)
