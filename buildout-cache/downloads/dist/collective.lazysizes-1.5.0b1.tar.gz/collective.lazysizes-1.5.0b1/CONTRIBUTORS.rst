Share and Enjoy
===============

``collective.lazysizes`` would not have been possible without the contribution of the following people:

- Héctor Velarde
- `Alexander Farkas`_ (lazysizes)

You can find an updated list of package contributors on `GitHub`_.

Development sponsored by `Simples Consultoria`_.

.. _`Alexander Farkas`: https://github.com/aFarkas
.. _`GitHub`: https://github.com/collective/collective.lazysizes/contributors
.. _`Simples Consultoria`: http://www.simplesconsultoria.com.br/
