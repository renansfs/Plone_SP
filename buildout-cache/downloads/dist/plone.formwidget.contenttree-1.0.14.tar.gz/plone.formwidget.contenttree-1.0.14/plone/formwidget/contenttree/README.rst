Content tree widget
===================

plone.formwidget.contenttree provides a content tree browser widget based on
the jqueryFileTree widget.