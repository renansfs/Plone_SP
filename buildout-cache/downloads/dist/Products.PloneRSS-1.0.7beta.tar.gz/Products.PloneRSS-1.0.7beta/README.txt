Introduction
============

PloneRSS is a module for Plone which facilitates the merging of RSS newsfeeds into your PloneCMS or Plone Website. The product is designed to work in a multi-user environment with a single process to bring in new feeds for the entire site. A news portlet is included as are facilities to display the merged results of multiple feeds within the same portlet or in multiple independent portlets.
