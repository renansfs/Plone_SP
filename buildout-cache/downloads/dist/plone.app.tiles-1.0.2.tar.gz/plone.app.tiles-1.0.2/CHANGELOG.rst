Changelog
=========

1.0.2 (2016-05-04)
------------------

- Remove cyclic dependency [fixes #7]
  [datakurre]

1.0.1 (2012-06-25)
------------------

- fixing 1.0 release which was broken (missing README.rst)
  [garbas]

1.0 (2012-06-23)
----------------

- initial release.
  [garbas]
