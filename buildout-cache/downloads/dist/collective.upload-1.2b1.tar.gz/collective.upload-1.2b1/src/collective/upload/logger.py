# -*- coding:utf-8 -*-
from collective.upload.config import PROJECTNAME

import logging


logger = logging.getLogger(PROJECTNAME)
