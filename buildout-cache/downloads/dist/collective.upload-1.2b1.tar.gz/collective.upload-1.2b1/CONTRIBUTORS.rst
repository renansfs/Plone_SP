Share and Enjoy
---------------

``collective.upload`` would not have been possible without the contribution of
the following people:

- Silvestre Huens
- Joaquín Rosales
- Héctor Velarde
- Gonzalo Almeida

You can find an updated list of package contributors on `GitHub`_.

``collective.upload`` is an implementation of the `jQuery File Upload`_ plugin
for Plone.

Development sponsored by Open Multimedia.

.. _`jQuery File Upload`: http://blueimp.github.com/jQuery-File-Upload/
.. _`GitHub`: https://github.com/collective/collective.upload/contributors
