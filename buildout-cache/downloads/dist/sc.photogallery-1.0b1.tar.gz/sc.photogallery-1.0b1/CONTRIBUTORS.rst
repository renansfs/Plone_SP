Share and Enjoy
===============

`sc.photogallery` would not have been possible without the contribution of the following people:

- André Nogueira
- Héctor Velarde
- Rodrigo Ferreira de Souza
- `Cycle2 slideshow plugin for jQuery`_
- Font Awesome (`icon`_)
- Wolfgang Beyer (`Mandelbrot image set`_ used in tests)

Development sponsored by Simples Consultoria.

.. _`Cycle2 slideshow plugin for jQuery`: http://jquery.malsup.com/cycle2/
.. _`icon`: http://fontawesome.io/icon/picture-o/
.. _`Mandelbrot image set`: https://commons.wikimedia.org/wiki/File:Mandel_zoom_00_mandelbrot_set.jpg
