# -*- coding: utf-8 -*-
from sc.photogallery.browser.view import View  # noqa
from sc.photogallery.browser.zip import ZipView  # noqa
