from zope.i18nmessageid import MessageFactory

pfr_message = MessageFactory('plone.formwidget.recurrence')
pl_message = MessageFactory('plonelocales')
