from zope.i18n import MessageFactory
siterssMessageFactory = MessageFactory('collective.siterss')