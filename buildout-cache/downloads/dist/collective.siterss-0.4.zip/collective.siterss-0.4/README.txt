Introduction
============

This product solves situation when you want to provide RSS feed of the site root
based on some Collection (Smart Folder) but you don't want to make the
Collection as default view of the site.

Allows to use one or more Smart Folders as source of Plone site RSS feeds. Site
visitor may select favorite feed from the Firefox addressbar menu for example or
subscribe to feed directly by any rss feed reader.

Additionally allows to append external rss feed to the feed list generated
above. This may be used on grouped portals, where one portal allows to
subscribe to the RSS feed from another site in the group.
