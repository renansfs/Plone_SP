Share and Enjoy
===============

`s17.portlets` would not have been possible without the contribution of the
following people:

- Silvestre Huens
- Cleber J Santos
- Héctor Velarde
- Alejandro Pereira
- Gustavo Lepri
- `Tango! Desktop Project`_ (image)

Development sponsored by Simples Consultoria.

.. _`Tango! Desktop Project`: http://tango.freedesktop.org/Tango_Desktop_Project
