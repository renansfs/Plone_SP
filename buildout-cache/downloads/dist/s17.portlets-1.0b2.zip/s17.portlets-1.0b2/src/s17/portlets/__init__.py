from zope.i18nmessageid import MessageFactory

PersonPortletsMessageFactory = MessageFactory('s17.portlets')
