from zope.interface import Interface


class IWhitePages(Interface):
    """
    A browser view for search persons
    """
