def sortTuple(t):
    l = sorted(t)
    return tuple(l)
