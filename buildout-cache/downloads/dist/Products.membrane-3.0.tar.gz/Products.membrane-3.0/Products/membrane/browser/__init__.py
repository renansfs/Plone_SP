"""
membrane browser package
"""
